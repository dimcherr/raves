import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.props import PointerProperty, StringProperty, CollectionProperty, FloatVectorProperty, FloatProperty, BoolProperty
import json
from bpy_extras.io_utils import ImportHelper, ExportHelper
from mathutils import Vector
import subprocess
import os
import shutil

handler = None

# Default categories (loaded if none exist in the scene)
defaultCategories = [
    ("Decor", "Objects doing nothing at all", (1.0, 1.0, 1.0, 1.0)),  # White
    ("Static", "Static objects", (0.2, 0.8, 0.2, 1.0)),  # Green
    ("Dynamic", "Dynamic objects", (0.8, 0.2, 0.2, 1.0)),  # Red
    ("Collision", "Collision objects", (0.2, 0.2, 0.8, 0.5)),  # Blue
    ("Door", "Door objects", (0.8, 0.8, 0.2, 1.0)),  # Yellow
    ("Key", "Key objects", (0.8, 0.2, 0.8, 1.0)),  # Magenta
    ("LightVolume", "Volume for lighting optimization", (0.5, 0.2, 0.5, 0.5)),  # Purple
]

# Property group for category float property definitions
class GlobalOptions(bpy.types.PropertyGroup):
    draw_relationships: BoolProperty(
        name="Draw Relationships",
        description="Display relationship lines",
        default=True
    )

# Property group for category float property definitions
class FloatPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the float property",
        default=""
    )
    default_value: FloatProperty(
        name="Default Value",
        description="Default value of the float property",
        default=0.0
    )

# Property group for object-specific float property values
class ObjectFloatPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the float property",
        default=""
    )
    value: FloatProperty(
        name="Value",
        description="Value of the float property for the object",
        default=0.0,
        update=lambda self, context: update_object_custom_properties(self, context)
    )

# Property group for category float property definitions
class StringPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the string property",
        default=""
    )
    default_value: StringProperty(
        name="Default Value",
        description="Default value of the string property",
        default=""
    )

# Property group for object-specific float property values
class ObjectStringPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the string property",
        default=""
    )
    value: StringProperty(
        name="Value",
        description="Value of the string property for the object",
        default="",
        update=lambda self, context: update_object_custom_properties(self, context)
    )

class RelationPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the relation property",
        default=""
    )
    default_value: PointerProperty(
        name="Default Value",
        description="Default value of the relation property",
        type=bpy.types.Object,
    )

# Property group for object-specific relation property values
class ObjectRelationPropertyItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Property Name",
        description="Name of the relation property",
        default=""
    )
    value: PointerProperty(
        name="Value",
        type=bpy.types.Object,
        description="Value of the relation property for the object",
        update=lambda self, context: update_object_custom_properties(self, context)
    )

# Property group for individual category items
class CategoryItem(bpy.types.PropertyGroup):
    name: StringProperty(
        name="Name",
        description="Unique identifier for the category",
        default=""
    )
    description: StringProperty(
        name="Description",
        description="Description of the category",
        default=""
    )
    color: FloatVectorProperty(
        name="Color",
        description="Color for the category in viewport",
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
        update=lambda self, context: update_colors(self, context)
    )
    visible: BoolProperty(
        name="Visible",
        description="Is category visible",
        default=True,
        update=lambda self, context: update_category_visibility(self, context)
    )
    float_properties: CollectionProperty(
        name="Float Properties",
        description="Float property definitions for the category",
        type=FloatPropertyItem
    )
    string_properties: CollectionProperty(
        name="String Properties",
        description="String property definitions for the category",
        type=StringPropertyItem
    )
    relation_properties: CollectionProperty(
        name="Relation Properties",
        description="Relation property definitions for the category",
        type=RelationPropertyItem
    )

# Custom property group for relationships and categories
class RelationshipProperties(bpy.types.PropertyGroup):
    category: StringProperty(
        name="Category",
        description="Assign a category to the object",
        update=lambda self, context: update_object_properties(context)
    )
    float_properties: CollectionProperty(
        name="Object Float Properties",
        description="Object-specific float property values",
        type=ObjectFloatPropertyItem
    )
    string_properties: CollectionProperty(
        name="Object String Properties",
        description="Object-specific string property values",
        type=ObjectStringPropertyItem
    )
    relation_properties: CollectionProperty(
        name="Object Relation Properties",
        description="Object-specific relation property values",
        type=ObjectRelationPropertyItem
    )

# Update object custom properties based on float properties
def update_all_custom_properties(context):
    update_viewport(context)

    objs = bpy.data.objects
    for obj in objs:
        category = obj.relationship.category
        
        # Get valid property names from category
        valid_float_prop_names = set()
        valid_string_prop_names = set()
        valid_relation_prop_names = set()
        if category:
            for cat in context.scene.tundra_categories:
                if cat.name == category:
                    valid_float_prop_names = {prop.name for prop in cat.float_properties}
                    valid_string_prop_names = {prop.name for prop in cat.string_properties}
                    valid_relation_prop_names = {prop.name for prop in cat.relation_properties}
                    break
        
        # Update custom properties
        obj_float_props = obj.relationship.float_properties
        for prop in obj_float_props:
            if prop.name in valid_float_prop_names:
                obj[prop.name] = prop.value

        obj_string_props = obj.relationship.string_properties
        for prop in obj_string_props:
            if prop.name in valid_string_prop_names:
                obj[prop.name] = prop.value

        obj_relation_props = obj.relationship.relation_properties
        for prop in obj_relation_props:
            if prop.name in valid_relation_prop_names:
                if prop.value:
                    obj[prop.name] = prop.value.name
                elif prop.name in obj:
                    del obj[prop.name]

        if "updating" in obj:
            del obj["updating"]

# Update object custom properties based on float properties
def update_object_custom_properties(selfprop, context):
    update_viewport(context)
    obj = context.active_object
    if not obj or "updating" in obj:
        return

    obj["updating"] = True
    
    category = obj.relationship.category
    
    # Get valid property names from category
    valid_float_prop_names = set()
    valid_string_prop_names = set()
    valid_relation_prop_names = set()
    if category:
        for cat in context.scene.tundra_categories:
            if cat.name == category:
                valid_float_prop_names = {prop.name for prop in cat.float_properties}
                valid_string_prop_names = {prop.name for prop in cat.string_properties}
                valid_relation_prop_names = {prop.name for prop in cat.relation_properties}
                break
    
    # Update custom properties
    obj_float_props = obj.relationship.float_properties
    for prop in obj_float_props:
        if prop.name in valid_float_prop_names:
            obj[prop.name] = prop.value

    obj_string_props = obj.relationship.string_properties
    for prop in obj_string_props:
        if prop.name in valid_string_prop_names:
            obj[prop.name] = prop.value

    obj_relation_props = obj.relationship.relation_properties
    for prop in obj_relation_props:
        if prop.name in valid_relation_prop_names:
            if prop.value:
                obj[prop.name] = prop.value.name
            elif prop.name in obj:
                del obj[prop.name]
    
    for selected_obj in context.selected_objects:
        if selected_obj != obj:
            if selfprop.name in selected_obj.relationship.float_properties:
                p = selected_obj.relationship.float_properties[selfprop.name]
                p.value = selfprop.value
                selected_obj[selfprop.name] = selfprop.value
            if selfprop.name in selected_obj.relationship.string_properties:
                p = selected_obj.relationship.string_properties[selfprop.name]
                p.value = selfprop.value
                selected_obj[selfprop.name] = selfprop.value
            if selfprop.name in selected_obj.relationship.relation_properties:
                p = selected_obj.relationship.relation_properties[selfprop.name]
                if selfprop.value:
                    p.value = selfprop.value
                    selected_obj[selfprop.name] = selfprop.value.name
                elif selfprop.name in selected_obj:
                    del selected_obj[p.name]

    del obj["updating"]

# Update Viewport for relationship lines
def update_viewport(context):
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()

def update_colors(prop, context):
    for obj in bpy.data.objects:
        if "category" in obj and obj["category"] == prop.name:
            obj.color = prop.color
    update_viewport(context)

def update_category_visibility(prop, context):
    for obj in bpy.data.objects:
        #obj.hide_viewport = False
        if "category" in obj and obj["category"] == prop.name:
            obj.hide_viewport = not prop.visible
    update_viewport(context)

# Update object color and float properties based on category
def update_object_properties(context):
    objs = bpy.context.selected_objects
    active_obj = bpy.context.active_object

    if len(objs) < 1 or "updating" in active_obj:
        return
    
    active_obj["updating"] = True
    for obj in objs:
        category = active_obj.relationship.category
        if category:
            for cat in context.scene.tundra_categories:
                if cat.name == category:
                    obj.color = cat.color
                    obj["category"] = category
                    if obj != active_obj:
                        obj.relationship.category = category
                    
                    # Update object float properties to match category
                    obj_float_props = obj.relationship.float_properties
                    obj_float_prop_names = {prop.name for prop in obj_float_props}
                    cat_float_props = {prop.name: prop.default_value for prop in cat.float_properties}

                    obj_string_props = obj.relationship.string_properties
                    obj_string_prop_names = {prop.name for prop in obj_string_props}
                    cat_string_props = {prop.name: prop.default_value for prop in cat.string_properties}

                    obj_relation_props = obj.relationship.relation_properties
                    obj_relation_prop_names = {prop.name for prop in obj_relation_props}
                    cat_relation_props = {prop.name: None for prop in cat.relation_properties}

                    # Remove object properties not in category
                    for i in reversed(range(len(obj_float_props))):
                        if obj_float_props[i].name not in cat_float_props:
                            obj_float_props.remove(i)

                    for i in reversed(range(len(obj_string_props))):
                        if obj_string_props[i].name not in cat_string_props:
                            obj_string_props.remove(i)

                    for i in reversed(range(len(obj_relation_props))):
                        if obj_relation_props[i].name not in cat_relation_props:
                            obj_relation_props.remove(i)
                    
                    # Add or update object properties from category
                    for prop_name, default_value in cat_float_props.items():
                        if prop_name not in obj_float_prop_names:
                            prop = obj_float_props.add()
                            prop.name = prop_name
                            prop.value = default_value
                        else:
                            for obj_prop in obj_float_props:
                                if obj_prop.name == prop_name:
                                    # Preserve existing value unless category changed
                                    if obj.relationship.category != active_obj.relationship.category:
                                        obj_prop.value = default_value
                                    break

                    for prop_name, default_value in cat_string_props.items():
                        if prop_name not in obj_string_prop_names:
                            prop = obj_string_props.add()
                            prop.name = prop_name
                            prop.value = default_value
                        else:
                            for obj_prop in obj_string_props:
                                if obj_prop.name == prop_name:
                                    # Preserve existing value unless category changed
                                    if obj.relationship.category != active_obj.relationship.category:
                                        obj_prop.value = default_value
                                    break

                    for prop_name, default_value in cat_relation_props.items():
                        if prop_name not in obj_relation_prop_names:
                            prop = obj_relation_props.add()
                            prop.name = prop_name
                            prop.value = default_value
                        else:
                            for obj_prop in obj_relation_props:
                                if obj_prop.name == prop_name:
                                    # Preserve existing value unless category changed
                                    if obj.relationship.category != active_obj.relationship.category:
                                        obj_prop.value = default_value
                                    break

                    break
            else:
                # Category not found, reset
                obj.color = (1.0, 1.0, 1.0, 1.0)
                obj["category"] = ""
                obj.relationship.float_properties.clear()
                obj.relationship.string_properties.clear()
                obj.relationship.relation_properties.clear()
                if obj != active_obj:
                    obj.relationship.category = ""
        else:
            obj.color = (1.0, 1.0, 1.0, 1.0)
            if "category" in obj:
                del obj["category"]
            obj.relationship.float_properties.clear()
            obj.relationship.string_properties.clear()
            obj.relationship.relation_properties.clear()
            if obj != active_obj:
                obj.relationship.category = ""
        update_viewport(context)
    active_obj["updating"] = False
    del active_obj["updating"]

# Operator to add a new category
class OBJECT_OT_AddCategory(bpy.types.Operator):
    bl_idname = "object.add_tundra_category"
    bl_label = "Add Category"
    
    name: StringProperty(name="Name", default="NewCategory")
    description: StringProperty(name="Description", default="A new category")
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        size=4,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0)
    )

    def execute(self, context):
        scene = context.scene
        if not self.name:
            self.report({'ERROR'}, "Category name cannot be empty!")
            return {'CANCELLED'}
        if any(cat.name == self.name for cat in scene.tundra_categories):
            self.report({'ERROR'}, f"Category '{self.name}' already exists!")
            return {'CANCELLED'}
        category = scene.tundra_categories.add()
        category.name = self.name
        category.description = self.description
        category.color = self.color
        update_viewport(context)
        self.report({'INFO'}, f"Added category '{self.name}'")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

# Operator to add a float property to a category
class OBJECT_OT_AddFloatProperty(bpy.types.Operator):
    bl_idname = "object.add_tundra_float_property"
    bl_label = "Add Float Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name", default="NewFloat")
    default_value: FloatProperty(name="Default Value", default=0.0)

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                if not self.prop_name:
                    self.report({'ERROR'}, "Property name cannot be empty!")
                    return {'CANCELLED'}
                if any(prop.name == self.prop_name for prop in cat.float_properties):
                    self.report({'ERROR'}, f"Property '{self.prop_name}' already exists in category '{cat.name}'!")
                    return {'CANCELLED'}
                prop = cat.float_properties.add()
                prop.name = self.prop_name
                prop.default_value = self.default_value
                # Update objects using this category
                for obj in bpy.data.objects:
                    if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                        obj_prop = obj.relationship.float_properties.add()
                        obj_prop.name = self.prop_name
                        obj_prop.value = self.default_value
                update_viewport(context)
                self.report({'INFO'}, f"Added float property '{self.prop_name}' to category '{cat.name}'")
                return {'FINISHED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class OBJECT_OT_AddStringProperty(bpy.types.Operator):
    bl_idname = "object.add_tundra_string_property"
    bl_label = "Add String Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name", default="NewString")
    default_value: StringProperty(name="Default Value", default="")

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                if not self.prop_name:
                    self.report({'ERROR'}, "Property name cannot be empty!")
                    return {'CANCELLED'}
                if any(prop.name == self.prop_name for prop in cat.string_properties):
                    self.report({'ERROR'}, f"Property '{self.prop_name}' already exists in category '{cat.name}'!")
                    return {'CANCELLED'}
                prop = cat.string_properties.add()
                prop.name = self.prop_name
                prop.default_value = self.default_value
                # Update objects using this category
                for obj in bpy.data.objects:
                    if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                        obj_prop = obj.relationship.string_properties.add()
                        obj_prop.name = self.prop_name
                        obj_prop.value = self.default_value
                update_viewport(context)
                self.report({'INFO'}, f"Added string property '{self.prop_name}' to category '{cat.name}'")
                return {'FINISHED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

class OBJECT_OT_AddRelationProperty(bpy.types.Operator):
    bl_idname = "object.add_tundra_relation_property"
    bl_label = "Add Relation Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name", default="NewRelation")

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                if not self.prop_name:
                    self.report({'ERROR'}, "Property name cannot be empty!")
                    return {'CANCELLED'}
                if any(prop.name == self.prop_name for prop in cat.relation_properties):
                    self.report({'ERROR'}, f"Property '{self.prop_name}' already exists in category '{cat.name}'!")
                    return {'CANCELLED'}
                prop = cat.relation_properties.add()
                prop.name = self.prop_name
                # Update objects using this category
                for obj in bpy.data.objects:
                    if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                        obj_prop = obj.relationship.relation_properties.add()
                        obj_prop.name = self.prop_name
                        obj_prop.value = None
                update_viewport(context)
                self.report({'INFO'}, f"Added relation property '{self.prop_name}' to category '{cat.name}'")
                return {'FINISHED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

# Operator to remove a float property from a category
class OBJECT_OT_RemoveFloatProperty(bpy.types.Operator):
    bl_idname = "object.remove_tundra_float_property"
    bl_label = "Remove Float Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name")

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                for i, prop in enumerate(cat.float_properties):
                    if prop.name == self.prop_name:
                        cat.float_properties.remove(i)
                        # Remove property from objects using this category
                        for obj in bpy.data.objects:
                            if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                                for j in reversed(range(len(obj.relationship.float_properties))):
                                    if obj.relationship.float_properties[j].name == self.prop_name:
                                        obj.relationship.float_properties.remove(j)
                                        if self.prop_name in obj:
                                            del obj[self.prop_name]
                        update_viewport(context)
                        self.report({'INFO'}, f"Removed float property '{self.prop_name}' from category '{cat.name}'")
                        return {'FINISHED'}
                self.report({'ERROR'}, f"Property '{self.prop_name}' not found in category '{cat.name}'!")
                return {'CANCELLED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

# Operator to remove a string property from a category
class OBJECT_OT_RemoveStringProperty(bpy.types.Operator):
    bl_idname = "object.remove_tundra_string_property"
    bl_label = "Remove String Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name")

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                for i, prop in enumerate(cat.string_properties):
                    if prop.name == self.prop_name:
                        cat.string_properties.remove(i)
                        # Remove property from objects using this category
                        for obj in bpy.data.objects:
                            if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                                for j in reversed(range(len(obj.relationship.string_properties))):
                                    if obj.relationship.string_properties[j].name == self.prop_name:
                                        obj.relationship.string_properties.remove(j)
                                        if self.prop_name in obj:
                                            del obj[self.prop_name]
                        update_viewport(context)
                        self.report({'INFO'}, f"Removed string property '{self.prop_name}' from category '{cat.name}'")
                        return {'FINISHED'}
                self.report({'ERROR'}, f"Property '{self.prop_name}' not found in category '{cat.name}'!")
                return {'CANCELLED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

class OBJECT_OT_RemoveRelationProperty(bpy.types.Operator):
    bl_idname = "object.remove_tundra_relation_property"
    bl_label = "Remove Relation Property"
    
    category_name: StringProperty(name="Category Name")
    prop_name: StringProperty(name="Property Name")

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        for cat in scene.tundra_categories:
            if cat.name == self.category_name:
                for i, prop in enumerate(cat.relation_properties):
                    if prop.name == self.prop_name:
                        cat.relation_properties.remove(i)
                        # Remove property from objects using this category
                        for obj in bpy.data.objects:
                            if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                                for j in reversed(range(len(obj.relationship.relation_properties))):
                                    if obj.relationship.relation_properties[j].name == self.prop_name:
                                        obj.relationship.relation_properties.remove(j)
                                        if self.prop_name in obj:
                                            del obj[self.prop_name]
                        update_viewport(context)
                        self.report({'INFO'}, f"Removed relation property '{self.prop_name}' from category '{cat.name}'")
                        return {'FINISHED'}
                self.report({'ERROR'}, f"Property '{self.prop_name}' not found in category '{cat.name}'!")
                return {'CANCELLED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

# Operator to remove a category
class OBJECT_OT_RemoveCategory(bpy.types.Operator):
    bl_idname = "object.remove_tundra_category"
    bl_label = "Remove Category"
    
    category_name: StringProperty(name="Category Name")

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        for i, cat in enumerate(scene.tundra_categories):
            if cat.name == self.category_name:
                for obj in bpy.data.objects:
                    if hasattr(obj, "relationship") and obj.relationship.category == self.category_name:
                        obj.relationship.category = ""
                        obj.color = (1.0, 1.0, 1.0, 1.0)
                        obj.relationship.float_properties.clear()
                        obj.relationship.string_properties.clear()
                        obj.relationship.relation_properties.clear()
                        if "category" in obj:
                            del obj["category"]
                scene.tundra_categories.remove(i)
                update_viewport(context)
                self.report({'INFO'}, f"Removed category '{self.category_name}'")
                return {'FINISHED'}
        self.report({'ERROR'}, f"Category '{self.category_name}' not found!")
        return {'CANCELLED'}

# Operator to save categories to JSON
class OBJECT_OT_SaveCategoriesJSON(bpy.types.Operator, ExportHelper):
    bl_idname = "object.save_tundra_categories_json"
    bl_label = "Save Categories to JSON"
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        categories = [
            {
                "name": cat.name,
                "description": cat.description,
                "color": list(cat.color),
                "float_properties": [
                    {"name": prop.name, "default_value": prop.default_value}
                    for prop in cat.float_properties
                ],
                "string_properties": [
                    {"name": prop.name, "default_value": prop.default_value}
                    for prop in cat.string_properties
                ],
                "relation_properties": [
                    {"name": prop.name, "default_value": prop.default_value}
                    for prop in cat.relation_properties
                ]
            } for cat in scene.tundra_categories
        ]
        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump({"categories": categories}, f, indent=4)
            self.report({'INFO'}, f"Saved categories to {self.filepath}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save JSON: {str(e)}")
            return {'CANCELLED'}

# Operator to load categories from JSON
class OBJECT_OT_LoadCategoriesJSON(bpy.types.Operator, ImportHelper):
    bl_idname = "object.load_tundra_categories_json"
    bl_label = "Load Categories from JSON"
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                categories = data.get("categories", [])
                
                # Clear existing categories
                scene.tundra_categories.clear()
                
                # Load new categories
                loaded_count = 0
                for cat_data in categories:
                    name = cat_data.get("name", "")
                    if not name or any(cat.name == name for cat in scene.tundra_categories):
                        continue  # Skip invalid or duplicate names
                    color = cat_data.get("color", [1.0, 1.0, 1.0, 1.0])
                    if len(color) != 4:
                        color = [1.0, 1.0, 1.0, 1.0]  # Fallback color
                    category = scene.tundra_categories.add()
                    category.name = name
                    category.description = cat_data.get("description", "")
                    category.color = color
                    
                    # Load float properties
                    for prop_data in cat_data.get("float_properties", []):
                        prop_name = prop_data.get("name", "")
                        if prop_name and not any(prop.name == prop_name for prop in category.float_properties):
                            prop = category.float_properties.add()
                            prop.name = prop_name
                            prop.default_value = prop_data.get("default_value", 0.0)

                    for prop_data in cat_data.get("string_properties", []):
                        prop_name = prop_data.get("name", "")
                        if prop_name and not any(prop.name == prop_name for prop in category.string_properties):
                            prop = category.string_properties.add()
                            prop.name = prop_name
                            prop.default_value = prop_data.get("default_value", 0.0)

                    for prop_data in cat_data.get("relation_properties", []):
                        prop_name = prop_data.get("name", "")
                        if prop_name and not any(prop.name == prop_name for prop in category.relation_properties):
                            prop = category.relation_properties.add()
                            prop.name = prop_name
                            prop.default_value = prop_data.get("default_value", 0.0)
                    
                    loaded_count += 1
                
                # Update objects to match new categories
                for obj in bpy.data.objects:
                    if hasattr(obj, "relationship") and obj.relationship.category:
                        if not any(cat.name == obj.relationship.category for cat in scene.tundra_categories):
                            obj.relationship.category = ""
                            obj.color = (1.0, 1.0, 1.0, 1.0)
                            obj.relationship.float_properties.clear()
                            obj.relationship.string_properties.clear()
                            obj.relationship.relation_properties.clear()
                            if "category" in obj:
                                del obj["category"]
                        else:
                            # Update float properties for objects with valid categories
                            for cat in scene.tundra_categories:
                                if cat.name == obj.relationship.category:
                                    obj_float_props = obj.relationship.float_properties
                                    obj_float_prop_names = {prop.name for prop in obj_float_props}
                                    cat_float_props = {prop.name: prop.default_value for prop in cat.float_properties}
                                    
                                    # Remove invalid properties
                                    for i in reversed(range(len(obj_float_props))):
                                        if obj_float_props[i].name not in cat_float_props:
                                            obj_float_props.remove(i)
                                    
                                    # Add missing properties
                                    for prop_name, default_value in cat_float_props.items():
                                        if prop_name not in obj_float_prop_names:
                                            prop = obj_float_props.add()
                                            prop.name = prop_name
                                            prop.value = default_value

                                    obj_string_props = obj.relationship.string_properties
                                    obj_string_prop_names = {prop.name for prop in obj_string_props}
                                    cat_string_props = {prop.name: prop.default_value for prop in cat.string_properties}
                                    
                                    # Remove invalid properties
                                    for i in reversed(range(len(obj_string_props))):
                                        if obj_string_props[i].name not in cat_string_props:
                                            obj_string_props.remove(i)
                                    
                                    # Add missing properties
                                    for prop_name, default_value in cat_string_props.items():
                                        if prop_name not in obj_string_prop_names:
                                            prop = obj_string_props.add()
                                            prop.name = prop_name
                                            prop.value = default_value

                                    obj_relation_props = obj.relationship.relation_properties
                                    obj_relation_prop_names = {prop.name for prop in obj_relation_props}
                                    cat_relation_props = {prop.name: prop.default_value for prop in cat.relation_properties}
                                    
                                    # Remove invalid properties
                                    for i in reversed(range(len(obj_relation_props))):
                                        if obj_relation_props[i].name not in cat_relation_props:
                                            obj_relation_props.remove(i)
                                    
                                    # Add missing properties
                                    for prop_name, default_value in cat_relation_props.items():
                                        if prop_name not in obj_relation_prop_names:
                                            prop = obj_relation_props.add()
                                            prop.name = prop_name
                                            prop.value = default_value

                                    break
                
                update_viewport(context)
                self.report({'INFO'}, f"Loaded {loaded_count} categories from {self.filepath}")
                return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load JSON: {str(e)}")
            return {'CANCELLED'}

# Operator to select objects with the same category
class OBJECT_OT_SelectSame(bpy.types.Operator):
    bl_idname = "object.select_same_category"
    bl_label = "Select Same"
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or not active_obj.relationship.category:
            self.report({'ERROR'}, "No active object or category selected!")
            return {'CANCELLED'}
        
        target_cats = [obj.relationship.category for obj in context.selected_objects if obj.relationship.category]
        bpy.ops.object.select_all(action='DESELECT')
        
        selected_count = 0
        for obj in bpy.data.objects:
            if hasattr(obj, "relationship") and obj.relationship.category in target_cats:
                obj.select_set(True)
                selected_count += 1
        
        active_obj.select_set(True)
        context.view_layer.objects.active = active_obj
        self.report({'INFO'}, f"Selected {selected_count} objects with categories {target_cats}")
        return {'FINISHED'}

class OBJECT_PT_CustomCategories(bpy.types.Panel):
    bl_label = "Tundra"
    bl_idname = "PT_CustomCategories"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tundra'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        # Category management
        #layout.label(text="Manage Categories")
        row = layout.row()
        row.operator("object.add_tundra_category", text="Add Category")
        row.operator("object.save_tundra_categories_json", text="Save to JSON")
        row.operator("object.load_tundra_categories_json", text="Load from JSON")
        
        for cat in scene.tundra_categories:
            box = layout.box()
            box.label(text=cat.name)
            row = box.row()
            row.label(text=cat.description)
            row = box.row()
            row.prop(cat, "color", text="Color")
            
            # Float property definitions
            for prop in cat.float_properties:
                row = box.row()
                row.label(text=f'[Float] {prop.name}')
                op = row.operator("object.remove_tundra_float_property", text="Remove")
                op.category_name = cat.name
                op.prop_name = prop.name

            for prop in cat.string_properties:
                row = box.row()
                row.label(text=f'[String] {prop.name}')
                op = row.operator("object.remove_tundra_string_property", text="Remove")
                op.category_name = cat.name
                op.prop_name = prop.name

            for prop in cat.relation_properties:
                row = box.row()
                row.label(text=f'[Relation] {prop.name}')
                op = row.operator("object.remove_tundra_relation_property", text="Remove")
                op.category_name = cat.name
                op.prop_name = prop.name
            
            row = box.row()
            op = row.operator("object.add_tundra_float_property", text="Float")
            op.category_name = cat.name

            op = row.operator("object.add_tundra_string_property", text="String")
            op.category_name = cat.name

            op = row.operator("object.add_tundra_relation_property", text="Relation")
            op.category_name = cat.name
            
            op = row.operator("object.remove_tundra_category", text="Remove")
            op.category_name = cat.name

# Panel filter categories 
class OBJECT_PT_TundraFilter(bpy.types.Panel):
    bl_label = "Filter"
    bl_idname = "PT_TundraFilter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tundra'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.operator("object.show_all_categories")
        layout.operator("object.hide_all_categories")
        
        for c in scene.tundra_categories:
            layout.row().prop(c, "visible", text=c.name)

# Panel for UI
class OBJECT_PT_CustomRelationship(bpy.types.Panel):
    bl_label = "Item"
    bl_idname = "PT_CustomRelationship"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tundra'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.active_object

        layout.row().prop(scene, "draw_relationships", text="Draw Relationships")
        
        # Object-specific properties
        if obj:
            layout.operator("object.update_all_custom_properties")
            layout.operator("object.export_gltf")
            layout.operator("object.export_animations")
            layout.operator("object.select_same_category")
            layout.prop_search(obj.relationship, "category", scene, "tundra_categories", text="Category")
            selected_category = obj.relationship.category
            if selected_category:
                # Display object-specific float properties
                for cat in scene.tundra_categories:
                    if cat.name == selected_category:
                        if len(obj.relationship.float_properties) > 0:
                            box = layout.box()
                            box.label(text="Float Properties")
                            for prop in obj.relationship.float_properties:
                                if any(cat_prop.name == prop.name for cat_prop in cat.float_properties):
                                    row = box.row()
                                    row.prop(prop, "value", text=prop.name)
                            break

                for cat in scene.tundra_categories:
                    if cat.name == selected_category:
                        if len(obj.relationship.string_properties) > 0:
                            box = layout.box()
                            box.label(text="String Properties")
                            for prop in obj.relationship.string_properties:
                                if any(cat_prop.name == prop.name for cat_prop in cat.string_properties):
                                    row = box.row()
                                    row.prop(prop, "value", text=prop.name)
                            break

                for cat in scene.tundra_categories:
                    if cat.name == selected_category:
                        if len(obj.relationship.relation_properties) > 0:
                            box = layout.box()
                            box.label(text="Relation Properties")
                            for prop in obj.relationship.relation_properties:
                                if any(cat_prop.name == prop.name for cat_prop in cat.relation_properties):
                                    row = box.row()
                                    row.prop(prop, "value", text=prop.name)
                            break

def exportAnim(filepath):
    print("EXPORT ANIM {}".format(filepath))
    skelname = filepath.split("\\")[-1].replace(".glb", "")
    rootpath = filepath.replace("\\res\\models\\{}.glb".format(skelname), "")
    os.chdir(rootpath)
    bpy.ops.export_scene.gltf(
        filepath=filepath,
        export_format='GLB',  # Options: 'GLTF_SEPARATE', 'GLTF_EMBEDDED', 'GLB'
        use_selection=True,            # Export entire scene; set to True for selected objects only
        use_visible=False,
        export_animations=True,
        export_vertex_color="NONE",
        export_all_vertex_colors=False,
        export_tangents=True,
        export_lights=True,
        export_extras=True,
        export_apply=True,
        export_materials='EXPORT',
        export_yup=True,
        export_animation_mode="NLA_TRACKS",
        export_nla_strips=True,
        export_force_sampling=False,
        export_optimize_animation_size=False,
        export_hierarchy_flatten_objs=True,
    )

#    print("ROOT PATH {}".format(rootpath))

    scriptpath = "{}\\tools\\gltf2ozz.exe".format(rootpath)

    #try:
        #result = subprocess.run([scriptpath, "--file={}".format(filepath), "--config_file={}\\ozzconfig.json".format(rootpath)], text=True, capture_output=True)
    subprocess.call([scriptpath, "--file={}".format(filepath), "--config_file={}\\ozzconfig.json".format(rootpath)])
        #print("GLTF2OZZ RESULT: {}".format(result))
    #except Exception as e:
        #print("EXCEPTION")
        #print(e)

    #print("WTF {}".format(result))

    #print("SKELETONOZZPATH={} NEWPATH={}".format("{}\\skeleton.ozz".format(rootpath), "{}\\res\\models\\{}.ozz".format(rootpath,skelname)))

    skelnameclean = skelname.replace("Skeleton", "")
    try:
        os.makedirs("{}\\res\\animations\\{}".format(rootpath, skelnameclean))
    except Exception as e:
        pass

    skelpathtarget = "{}\\res\\animations\\{}\\_Skeleton.ozz".format(rootpath, skelnameclean)
    try:
        os.remove(skelpathtarget)
    except Exception as e:
        pass
    shutil.move("{}\\skeleton.ozz".format(rootpath), skelpathtarget)
    for f in os.listdir("."):
        if f.endswith(".ozz"):
            ffname = f.split("\\")[-1]
            if ffname.startswith(skelnameclean):
                animpathtarget = "{}\\res\\animations\\{}\\{}".format(rootpath, skelnameclean, ffname.replace(skelnameclean, ""))
                try:
                    os.remove(animpathtarget)
                except Exception as e:
                    pass
                shutil.move("{}\\{}".format(rootpath, f), animpathtarget)
            else:
                os.remove(f)
    os.remove(filepath)

def exportGLTF():
    for obj in bpy.context.scene.objects:
        obj.hide_viewport = False

    bpy.ops.export_scene.gltf(
        filepath=bpy.data.filepath.replace(".blend", ".glb").replace("assets", "res"),
        export_format='GLB',  # Options: 'GLTF_SEPARATE', 'GLTF_EMBEDDED', 'GLB'
        use_selection=False,            # Export entire scene; set to True for selected objects only
        use_visible=False,
        export_animations=False,
        export_vertex_color="NONE",
        export_all_vertex_colors=False,
        export_tangents=True,
        export_lights=True,
        export_extras=True,
        export_apply=True,
        export_materials='EXPORT',
        export_yup=True,
        export_hierarchy_flatten_objs=True
    )

    for c in bpy.context.scene.tundra_categories:
        for obj in bpy.data.objects:
            if "category" in obj and obj["category"] == c.name:
                obj.hide_viewport = not c.visible

class OBJECT_OT_ShowAllCategories(bpy.types.Operator):
    """Show all categories"""
    bl_idname = "object.show_all_categories"
    bl_label = "Show All"

    def execute(self, context):
        for obj in bpy.data.objects:
            obj.hide_viewport = False
        for cat in context.scene.tundra_categories:
            cat.visible = True
        update_viewport(context)
        #print("Show all")
        return {'FINISHED'}

class OBJECT_OT_HideAllCategories(bpy.types.Operator):
    """Hide all categories"""
    bl_idname = "object.hide_all_categories"
    bl_label = "Hide All"

    def execute(self, context):
        for cat in context.scene.tundra_categories:
            cat.visible = False
        update_viewport(context)
        print("Hide all")
        return {'FINISHED'}

class OBJECT_OT_UpdateAll(bpy.types.Operator):
    """Update all custom properties"""
    bl_idname = "object.update_all_custom_properties"
    bl_label = "Update All Properties"

    def execute(self, context):
        # Export the scene as glTF
        update_all_custom_properties(bpy.context)
        self.report({'INFO'}, 'UPDATED ALL PROPS')
        return {'FINISHED'}

# Custom operator for glTF export
class OBJECT_OT_ExportGLTF(bpy.types.Operator):
    """Export scene as glTF file"""
    bl_idname = "object.export_gltf"
    bl_label = "Export Scene"

    def execute(self, context):
        # Export the scene as glTF
        exportGLTF()
        self.report({'INFO'}, 'EXPORTED SCENE TO {}'.format(bpy.data.filepath.replace(".blend", ".glb").replace("assets", "res")))
        return {'FINISHED'}

# Custom operator for glTF export
class OBJECT_OT_ExportAnimations(bpy.types.Operator):
    """Export scene and animations as glTF file and convert to OZZ"""
    bl_idname = "object.export_animations"
    bl_label = "Export Animations"

    def execute(self, context):
        exportGLTF()

        for obj in bpy.context.scene.objects:
            obj.hide_viewport = False

        filepath = bpy.data.filepath.replace(".blend", ".glb").replace("assets", "res")
        self.report({'INFO'}, 'EXPORTED SCENE TO {}'.format(filepath))
        
        # Iterate through all objects in the current scene
        #print("LIST ARMATURES...")
        for obj in bpy.context.scene.objects:
            if obj.type == 'ARMATURE':
                bpy.ops.object.select_all(action='DESELECT')
                oldfilename = filepath.split("\\")[-1]
                newfilename = obj.name + ".glb"
                fullpath = filepath.replace(oldfilename, newfilename)
                obj.select_set(True)
                for c in obj.children:
                    c.select_set(True)
                exportAnim(fullpath)
                self.report({'INFO'}, f"Exported Animations for {fullpath}")

        for c in bpy.context.scene.tundra_categories:
            for obj in bpy.data.objects:
                if "category" in obj and obj["category"] == c.name:
                    obj.hide_viewport = not c.visible

        self.report({'INFO'}, f"Exported Scene and Animations!")
        return {'FINISHED'}

# Draw handler for relationship lines
def draw_relationship_lines():
    if "draw_relationships" not in bpy.context.scene or not bpy.context.scene["draw_relationships"]:
        return

    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float("color", (1, 1, 0, 1))  # Yellow line
    
    #objs = bpy.context.selected_objects
    objs = bpy.data.objects
    for obj in objs:
        if len(obj.relationship.relation_properties) > 0:
            for related in obj.relationship.relation_properties:
                if not related.value:
                    continue
                if obj.hide_viewport or obj.hide_get(view_layer=bpy.context.view_layer):
                    continue
                if related.value.hide_viewport or related.value.hide_get(view_layer=bpy.context.view_layer):
                    continue

                cat = related.value["category"]
                if cat:
                    shader.uniform_float("color", bpy.context.scene.tundra_categories[cat].color)  # Yellow line
                start = obj.matrix_world.translation
                end = related.value.matrix_world.translation
                batch = batch_for_shader(shader, 'LINES', {"pos": [start, end]})
                batch.draw(shader)

# Initialize default categories if none exist
def initialize_categories(scene):
    if not scene.tundra_categories:
        for name, description, color in defaultCategories:
            category = scene.tundra_categories.add()
            category.name = name
            category.description = description
            category.color = color
            category.visible = True

# Register and unregister functions
def register():
    bpy.utils.register_class(GlobalOptions)
    bpy.utils.register_class(FloatPropertyItem)
    bpy.utils.register_class(ObjectFloatPropertyItem)
    bpy.utils.register_class(StringPropertyItem)
    bpy.utils.register_class(ObjectStringPropertyItem)
    bpy.utils.register_class(RelationPropertyItem)
    bpy.utils.register_class(ObjectRelationPropertyItem)
    bpy.utils.register_class(CategoryItem)
    bpy.utils.register_class(RelationshipProperties)
    bpy.utils.register_class(OBJECT_OT_AddCategory)
    bpy.utils.register_class(OBJECT_OT_AddFloatProperty)
    bpy.utils.register_class(OBJECT_OT_RemoveFloatProperty)
    bpy.utils.register_class(OBJECT_OT_AddStringProperty)
    bpy.utils.register_class(OBJECT_OT_RemoveStringProperty)
    bpy.utils.register_class(OBJECT_OT_AddRelationProperty)
    bpy.utils.register_class(OBJECT_OT_RemoveRelationProperty)
    bpy.utils.register_class(OBJECT_OT_RemoveCategory)
    bpy.utils.register_class(OBJECT_OT_SaveCategoriesJSON)
    bpy.utils.register_class(OBJECT_OT_LoadCategoriesJSON)
    bpy.utils.register_class(OBJECT_OT_SelectSame)
    bpy.utils.register_class(OBJECT_OT_ExportGLTF)
    bpy.utils.register_class(OBJECT_OT_UpdateAll)
    bpy.utils.register_class(OBJECT_OT_ShowAllCategories)
    bpy.utils.register_class(OBJECT_OT_HideAllCategories)
    bpy.utils.register_class(OBJECT_OT_ExportAnimations)
    bpy.utils.register_class(OBJECT_PT_CustomRelationship)
    bpy.utils.register_class(OBJECT_PT_TundraFilter)
    bpy.utils.register_class(OBJECT_PT_CustomCategories)
    
    # Define scene-level categories collection
    bpy.types.Scene.tundra_categories = CollectionProperty(type=CategoryItem)
    bpy.types.Scene.draw_relationships = BoolProperty(
        name="Draw Relationships",
        description="Display relationship lines",
        default=True
    )
    
    # Add custom property to Object type
    bpy.types.Object.relationship = PointerProperty(type=RelationshipProperties)
    
    # Initialize categories on file load
    bpy.app.handlers.load_post.append(lambda _dummy: initialize_categories(bpy.context.scene))
    
    # Add draw handler for Viewport
    global handler
    handler = bpy.types.SpaceView3D.draw_handler_add(draw_relationship_lines, (), 'WINDOW', 'POST_VIEW')

def unregister():
    global handler
    if handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(handler, 'WINDOW')
        handler = None
    
    bpy.utils.unregister_class(GlobalOptions)
    bpy.utils.unregister_class(FloatPropertyItem)
    bpy.utils.unregister_class(ObjectFloatPropertyItem)
    bpy.utils.unregister_class(StringPropertyItem)
    bpy.utils.unregister_class(ObjectStringPropertyItem)
    bpy.utils.unregister_class(RelationPropertyItem)
    bpy.utils.unregister_class(ObjectRelationPropertyItem)
    bpy.utils.unregister_class(CategoryItem)
    bpy.utils.unregister_class(RelationshipProperties)
    bpy.utils.unregister_class(OBJECT_OT_AddCategory)
    bpy.utils.unregister_class(OBJECT_OT_AddFloatProperty)
    bpy.utils.unregister_class(OBJECT_OT_RemoveFloatProperty)
    bpy.utils.unregister_class(OBJECT_OT_AddStringProperty)
    bpy.utils.unregister_class(OBJECT_OT_RemoveStringProperty)
    bpy.utils.unregister_class(OBJECT_OT_AddRelationProperty)
    bpy.utils.unregister_class(OBJECT_OT_RemoveRelationProperty)
    bpy.utils.unregister_class(OBJECT_OT_RemoveCategory)
    bpy.utils.unregister_class(OBJECT_OT_SaveCategoriesJSON)
    bpy.utils.unregister_class(OBJECT_OT_LoadCategoriesJSON)
    bpy.utils.unregister_class(OBJECT_OT_SelectSame)
    bpy.utils.unregister_class(OBJECT_OT_ExportGLTF)
    bpy.utils.unregister_class(OBJECT_OT_UpdateAll)
    bpy.utils.unregister_class(OBJECT_OT_ShowAllCategories)
    bpy.utils.unregister_class(OBJECT_OT_HideAllCategories)
    bpy.utils.unregister_class(OBJECT_OT_ExportAnimations)
    bpy.utils.unregister_class(OBJECT_PT_CustomRelationship)
    bpy.utils.unregister_class(OBJECT_PT_TundraFilter)
    bpy.utils.unregister_class(OBJECT_PT_CustomCategories)
    
    # Remove custom properties
    del bpy.types.Scene.tundra_categories
    del bpy.types.Scene.draw_relationships
    del bpy.types.Object.relationship
    
    # Remove load handler
    if initialize_categories in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(initialize_categories)

if __name__ == "__main__":
    register()